from __future__ import annotations

import json
import logging
import secrets
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from fastapi import Depends, FastAPI, Header, HTTPException
from google.oauth2.service_account import Credentials
from google.auth.exceptions import GoogleAuthError
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from httplib2 import HttpLib2Error
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.config import settings
from app.db import Base, engine, ensure_runtime_schema, get_db
from app.models import Reservation
from app.schemas import (
    CalendarSource,
    DayAvailability,
    ReservationCancelRequest,
    ReservationCancelResult,
    ReservationCreateRequest,
    ReservationCreateResult,
    SyncConfig,
    SlotResponse,
    SlotSearchRequest,
    SlotSearchResult,
)
from app.shared.error_contract import BookingApiErrorCode, api_error
from app.shared.time_utils import (
    has_time_overlap,
    parse_google_busy_response,
)
from app.services.config_store import load_sync_config, save_sync_config
from app.services.slots import search_slots
from app.services.google_availability import fetch_holiday_busy_ranges

app = FastAPI(title="Restatify Booking API", version="1.2.5")


@app.on_event("startup")
def startup() -> None:
    ensure_runtime_schema()


def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    if not settings.api_key:
        return
    if x_api_key != settings.api_key:
        raise api_error(401, BookingApiErrorCode.INVALID_API_KEY, "Invalid API key")


def _get_google_calendar_ids_for_check() -> list[str]:
    sync_config = load_sync_config()
    calendar_sources = sync_config.get("calendar_sources", []) if isinstance(sync_config, dict) else []
    plugin_ids = [
        str(item.get("calendar_id", "")).strip()
        for item in calendar_sources
        if isinstance(item, dict) and str(item.get("calendar_id", "")).strip() != ""
    ]

    env_ids = [item.strip() for item in settings.google_calendar_ids.split(",") if item.strip() != ""]

    merged: list[str] = []
    seen: set[str] = set()
    for calendar_id in env_ids + plugin_ids:
        if calendar_id in seen:
            continue
        seen.add(calendar_id)
        merged.append(calendar_id)

    return merged


def _get_google_calendar_ids_for_live_check() -> list[str]:
    sync_config = load_sync_config()
    calendar_sources = sync_config.get("calendar_sources", []) if isinstance(sync_config, dict) else []

    plugin_ids = [
        str(item.get("calendar_id", "")).strip()
        for item in calendar_sources
        if isinstance(item, dict)
        and str(item.get("calendar_id", "")).strip() != ""
        and str(item.get("calendar_type", "general")).strip().lower() != "holiday"
    ]

    env_ids = [item.strip() for item in settings.google_calendar_ids.split(",") if item.strip() != ""]

    merged: list[str] = []
    seen: set[str] = set()
    for calendar_id in env_ids + plugin_ids:
        if calendar_id in seen:
            continue
        seen.add(calendar_id)
        merged.append(calendar_id)

    return merged


def _get_google_holiday_calendar_ids_for_live_check() -> list[str]:
    sync_config = load_sync_config()
    calendar_sources = sync_config.get("calendar_sources", []) if isinstance(sync_config, dict) else []

    merged: list[str] = []
    seen: set[str] = set()
    for item in calendar_sources:
        if not isinstance(item, dict):
            continue

        calendar_id = str(item.get("calendar_id", "")).strip()
        if calendar_id == "":
            continue

        calendar_type = str(item.get("calendar_type", "general")).strip().lower()
        if calendar_type != "holiday":
            continue

        if calendar_id in seen:
            continue

        seen.add(calendar_id)
        merged.append(calendar_id)

    return merged


def _get_google_calendar_source_map() -> dict[str, dict]:
    sync_config = load_sync_config()
    calendar_sources = sync_config.get("calendar_sources", []) if isinstance(sync_config, dict) else []

    source_map: dict[str, dict] = {}
    for item in calendar_sources:
        if not isinstance(item, dict):
            continue

        calendar_id = str(item.get("calendar_id", "")).strip()
        if calendar_id == "":
            continue

        source_map[calendar_id] = item

    return source_map


def _get_google_calendar_id_for_write() -> str:
    sync_config = load_sync_config()
    configured = str(sync_config.get("write_calendar_id", "")).strip()
    if configured == "":
        configured = settings.google_write_calendar_id.strip()
    return configured


def _is_booking_backend_configured() -> bool:
    return len(_get_google_calendar_ids_for_check()) > 0


def _ensure_booking_backend_configured() -> None:
    if _is_booking_backend_configured():
        return

    raise api_error(
        503,
        BookingApiErrorCode.BACKEND_UNAVAILABLE,
        "Booking backend is currently unavailable. Please try again later.",
    )


def _google_availability_unavailable() -> HTTPException:
    return api_error(
        503,
        BookingApiErrorCode.BACKEND_UNAVAILABLE,
        "Calendar availability could not be verified. Please try again later.",
    )


def _get_google_live_busy_ranges(start_utc: datetime, end_utc: datetime) -> list[tuple[datetime, datetime]]:
    """Fetch complete current busy data; an unverified calendar is never free."""
    credentials_json = settings.google_credentials_json.strip()
    general_calendar_ids = _get_google_calendar_ids_for_live_check()
    holiday_calendar_ids = _get_google_holiday_calendar_ids_for_live_check()
    if credentials_json == "" or (len(general_calendar_ids) == 0 and len(holiday_calendar_ids) == 0):
        raise _google_availability_unavailable()

    try:
        creds_payload = json.loads(credentials_json)
        credentials = Credentials.from_service_account_info(
            creds_payload,
            scopes=["https://www.googleapis.com/auth/calendar.readonly"],
        )
        service = build("calendar", "v3", credentials=credentials, cache_discovery=False)
    except (ValueError, TypeError, KeyError, GoogleAuthError, HttpError, HttpLib2Error, OSError) as exc:
        logging.getLogger(__name__).exception("Google availability client initialization failed")
        raise _google_availability_unavailable() from exc

    ranges: list[tuple[datetime, datetime]] = []
    for batch_start in range(0, len(general_calendar_ids), 50):
        batch = general_calendar_ids[batch_start:batch_start + 50]
        try:
            result = service.freebusy().query(
                body={
                    "timeMin": start_utc.isoformat(),
                    "timeMax": end_utc.isoformat(),
                    "items": [{"id": cal_id} for cal_id in batch],
                }
            ).execute()
        except (GoogleAuthError, HttpError, HttpLib2Error, OSError) as exc:
            logging.getLogger(__name__).exception("Google live FreeBusy request failed")
            raise _google_availability_unavailable() from exc

        try:
            for busy in parse_google_busy_response(result, batch).values():
                ranges.extend(busy)
        except ValueError as exc:
            logging.getLogger(__name__).warning("Incomplete or invalid Google FreeBusy response")
            raise _google_availability_unavailable() from exc

    for calendar_id in holiday_calendar_ids:
        try:
            ranges.extend(fetch_holiday_busy_ranges(service, calendar_id, start_utc, end_utc))
        except (ValueError, GoogleAuthError, HttpError, HttpLib2Error, OSError) as exc:
            logging.getLogger(__name__).exception("Google live holiday verification failed")
            raise _google_availability_unavailable() from exc
    return ranges


def _ensure_no_google_live_conflict(start_utc: datetime, end_utc: datetime) -> None:
    for busy_start, busy_end in _get_google_live_busy_ranges(start_utc, end_utc):
        if has_time_overlap(start_utc, end_utc, busy_start, busy_end):
            raise api_error(409, BookingApiErrorCode.GOOGLE_SLOT_CONFLICT, "Slot conflicts with current Google calendar data")


def _create_google_calendar_event(
    *,
    reference: str,
    name: str,
    email: str,
    note: str,
    timezone_name: str,
    start_dt: datetime,
    end_dt: datetime,
) -> tuple[str, str]:
    sync_config = load_sync_config()
    write_events_enabled = bool(sync_config.get("write_events_enabled", settings.google_write_events_enabled))
    if not write_events_enabled:
        return "", ""

    credentials_json = settings.google_credentials_json.strip()
    if credentials_json == "":
        raise HTTPException(status_code=503, detail="Google calendar write is not configured (missing credentials)")

    calendar_id = _get_google_calendar_id_for_write()
    if calendar_id == "":
        raise HTTPException(status_code=503, detail="Google calendar write is not configured (write_calendar_id is required)")

    try:
        creds_payload = json.loads(credentials_json)
        credentials = Credentials.from_service_account_info(
            creds_payload,
            scopes=["https://www.googleapis.com/auth/calendar"],
        )
        service = build("calendar", "v3", credentials=credentials, cache_discovery=False)

        description_lines = [f"Reference: {reference}"]
        if note.strip() != "":
            description_lines.append("")
            description_lines.append(note.strip())

        body = {
            "summary": f"Booking: {name}",
            "description": "\n".join(description_lines),
            "start": {
                "dateTime": start_dt.isoformat(),
                "timeZone": timezone_name,
            },
            "end": {
                "dateTime": end_dt.isoformat(),
                "timeZone": timezone_name,
            },
            "attendees": [{"email": email}],
        }

        try:
            created_event = service.events().insert(
                calendarId=calendar_id,
                body=body,
                sendUpdates="all",
            ).execute()
        except HttpError as exc:
            # Service accounts without domain-wide delegation cannot invite attendees.
            # Retry by creating the event without attendees and without invitation emails.
            message = str(exc)
            if "forbiddenForServiceAccounts" not in message:
                raise

            fallback_body = dict(body)
            fallback_body.pop("attendees", None)
            created_event = service.events().insert(
                calendarId=calendar_id,
                body=fallback_body,
                sendUpdates="none",
            ).execute()
        return str(created_event.get("id", "")).strip(), calendar_id
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not create Google calendar event: {exc}") from exc


def _delete_google_calendar_event(*, calendar_id: str, event_id: str) -> None:
    credentials_json = settings.google_credentials_json.strip()
    if credentials_json == "" or calendar_id.strip() == "" or event_id.strip() == "":
        return

    try:
        creds_payload = json.loads(credentials_json)
        credentials = Credentials.from_service_account_info(
            creds_payload,
            scopes=["https://www.googleapis.com/auth/calendar"],
        )
        service = build("calendar", "v3", credentials=credentials, cache_discovery=False)
        service.events().delete(calendarId=calendar_id, eventId=event_id, sendUpdates="all").execute()
    except HttpError as exc:
        status_code = getattr(getattr(exc, "resp", None), "status", None)
        if status_code == 404:
            return
        raise HTTPException(status_code=502, detail=f"Could not delete Google calendar event: {exc}") from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not delete Google calendar event: {exc}") from exc


def _has_local_reservation_overlap(db: Session, start_utc: datetime, end_utc: datetime) -> bool:
    stmt = select(Reservation).where(
        and_(
            Reservation.status.in_(["held", "confirmed"]),
            or_(
                and_(Reservation.start_utc >= start_utc, Reservation.start_utc < end_utc),
                and_(Reservation.end_utc > start_utc, Reservation.end_utc <= end_utc),
                and_(Reservation.start_utc <= start_utc, Reservation.end_utc >= end_utc),
            ),
        )
    )
    return db.execute(stmt).scalar_one_or_none() is not None


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/slots/search", response_model=SlotSearchResult, dependencies=[Depends(require_api_key)])
def slots_search(payload: SlotSearchRequest, db: Session = Depends(get_db)) -> SlotSearchResult:
    _ensure_booking_backend_configured()

    slots = search_slots(db, payload.start_iso, payload.end_iso, payload.duration_minutes, payload.timezone)
    zone = ZoneInfo(payload.timezone)
    window_start = payload.start_iso
    if window_start.tzinfo is None:
        window_start = window_start.replace(tzinfo=zone)
    window_start = window_start.astimezone(timezone.utc)
    window_end = payload.end_iso
    if window_end.tzinfo is None:
        window_end = window_end.replace(tzinfo=zone)
    window_end = min(window_end.astimezone(timezone.utc), window_start + timedelta(days=settings.max_window_days))
    if window_end <= window_start:
        return SlotSearchResult(timezone=payload.timezone, duration_minutes=payload.duration_minutes, slots=[])
    busy_ranges = _get_google_live_busy_ranges(
        window_start.astimezone(timezone.utc), window_end.astimezone(timezone.utc),
    )
    slots = [
        item for item in slots
        if not any(
            has_time_overlap(
                datetime.fromisoformat(item["start_iso"]),
                datetime.fromisoformat(item["end_iso"]),
                busy_start, busy_end,
            )
            for busy_start, busy_end in busy_ranges
        )
    ]
    return SlotSearchResult(
        timezone=payload.timezone,
        duration_minutes=payload.duration_minutes,
        slots=[SlotResponse(**item) for item in slots],
    )


@app.post("/v1/reservations", response_model=ReservationCreateResult, dependencies=[Depends(require_api_key)])
def create_reservation(payload: ReservationCreateRequest, db: Session = Depends(get_db)) -> ReservationCreateResult:
    _ensure_booking_backend_configured()

    start_dt = payload.start_iso
    if start_dt.tzinfo is None:
        raise api_error(400, BookingApiErrorCode.START_ISO_TIMEZONE_REQUIRED, "start_iso must include timezone")

    end_dt = start_dt + timedelta(minutes=payload.duration_minutes)

    existing = search_slots(db, payload.start_iso, end_dt, payload.duration_minutes, payload.timezone)
    start_key = payload.start_iso.isoformat()
    is_available = any(item["start_iso"] == start_key for item in existing)
    if not is_available:
        raise api_error(409, BookingApiErrorCode.SLOT_UNAVAILABLE, "Slot is no longer available")

    start_utc = start_dt.astimezone(timezone.utc)
    end_utc = end_dt.astimezone(timezone.utc)

    # Recheck overlap right before commit to reduce race-condition double-bookings.
    if _has_local_reservation_overlap(db, start_utc, end_utc):
        raise api_error(409, BookingApiErrorCode.SLOT_RESERVED, "Slot is already reserved")

    # Mandatory recheck also catches changes since the visitor loaded the slot list.
    _ensure_no_google_live_conflict(start_utc, end_utc)

    reference = "RBK-" + secrets.token_hex(5).upper()
    cancel_token = secrets.token_urlsafe(24)
    google_event_id, google_event_calendar_id = _create_google_calendar_event(
        reference=reference,
        name=payload.name,
        email=str(payload.email),
        note=payload.note,
        timezone_name=payload.timezone,
        start_dt=start_dt,
        end_dt=end_dt,
    )

    reservation = Reservation(
        reference=reference,
        cancel_token=cancel_token,
        name=payload.name,
        email=str(payload.email),
        note=payload.note,
        timezone=payload.timezone,
        start_utc=start_utc,
        end_utc=end_utc,
        status="confirmed",
        cancellation_reason="",
        cancellation_message="",
        cancelled_at_utc=None,
        google_event_id=google_event_id,
        google_event_calendar_id=google_event_calendar_id,
        created_at_utc=datetime.now(timezone.utc),
    )

    db.add(reservation)
    db.commit()

    return ReservationCreateResult(
        reference=reference,
        cancel_token=cancel_token,
        status="confirmed",
        start_iso=payload.start_iso.isoformat(),
        end_iso=end_dt.isoformat(),
    )


@app.post("/v1/reservations/cancel", response_model=ReservationCancelResult, dependencies=[Depends(require_api_key)])
def cancel_reservation(payload: ReservationCancelRequest, db: Session = Depends(get_db)) -> ReservationCancelResult:
    stmt = select(Reservation).where(Reservation.cancel_token == payload.cancel_token)
    reservation = db.execute(stmt).scalar_one_or_none()
    if reservation is None:
        raise api_error(404, BookingApiErrorCode.CANCELLATION_TOKEN_INVALID, "Cancellation token is invalid")

    if reservation.status == "cancelled":
        return ReservationCancelResult(
            already_cancelled=True,
            reference=reservation.reference,
            name=reservation.name,
            email=reservation.email,
            timezone=reservation.timezone,
            cancellation_reason=reservation.cancellation_reason,
            cancellation_message=reservation.cancellation_message,
            status="cancelled",
            start_iso=reservation.start_utc.astimezone(timezone.utc).isoformat(),
            end_iso=reservation.end_utc.astimezone(timezone.utc).isoformat(),
        )

    if reservation.status not in ("confirmed", "held"):
        raise api_error(409, BookingApiErrorCode.CANCELLATION_NOT_ALLOWED, "Reservation can no longer be cancelled")

    _delete_google_calendar_event(
        calendar_id=reservation.google_event_calendar_id,
        event_id=reservation.google_event_id,
    )

    reservation.status = "cancelled"
    reservation.cancellation_reason = payload.reason.strip()
    reservation.cancellation_message = payload.message.strip()
    reservation.cancelled_at_utc = datetime.now(timezone.utc)
    db.add(reservation)
    db.commit()

    return ReservationCancelResult(
        already_cancelled=False,
        reference=reservation.reference,
        name=reservation.name,
        email=reservation.email,
        timezone=reservation.timezone,
        cancellation_reason=reservation.cancellation_reason,
        cancellation_message=reservation.cancellation_message,
        status="cancelled",
        start_iso=reservation.start_utc.astimezone(timezone.utc).isoformat(),
        end_iso=reservation.end_utc.astimezone(timezone.utc).isoformat(),
    )


@app.get("/v1/config/sync", response_model=SyncConfig, dependencies=[Depends(require_api_key)])
def get_sync_config() -> SyncConfig:
    config = load_sync_config()
    return SyncConfig(
        sync_enabled=bool(config.get("sync_enabled", True)),
        sync_interval_minutes=int(config.get("sync_interval_minutes", 15)),
        calendar_sources=[CalendarSource(**item) for item in config.get("calendar_sources", []) if isinstance(item, dict)],
        availability_rules=[DayAvailability(**item) for item in config.get("availability_rules", []) if isinstance(item, dict)],
        write_events_enabled=bool(config.get("write_events_enabled", settings.google_write_events_enabled)),
        write_calendar_id=str(config.get("write_calendar_id", settings.google_write_calendar_id)).strip(),
    )


@app.put("/v1/config/sync", response_model=SyncConfig, dependencies=[Depends(require_api_key)])
def update_sync_config(payload: SyncConfig) -> SyncConfig:
    config = save_sync_config(payload.model_dump())
    return SyncConfig(
        sync_enabled=bool(config.get("sync_enabled", True)),
        sync_interval_minutes=int(config.get("sync_interval_minutes", 15)),
        calendar_sources=[CalendarSource(**item) for item in config.get("calendar_sources", []) if isinstance(item, dict)],
        availability_rules=[DayAvailability(**item) for item in config.get("availability_rules", []) if isinstance(item, dict)],
        write_events_enabled=bool(config.get("write_events_enabled", settings.google_write_events_enabled)),
        write_calendar_id=str(config.get("write_calendar_id", settings.google_write_calendar_id)).strip(),
    )
